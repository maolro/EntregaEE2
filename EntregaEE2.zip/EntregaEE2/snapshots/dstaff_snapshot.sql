{% snapshot dstaff_snapshot %}

{{ config(
    target_schema=var('schema_star'),
    unique_key='staff_id',
    strategy='timestamp',
    updated_at='last_update'
) }}

SELECT
    staff_skey,
    staff_id,
    staff_first_name,
    staff_last_name,
    staff_email,
    staff_active,
    staff_store_id,
    staff_last_update
FROM {{ ref('stg_staff') }}

{% endsnapshot %}

