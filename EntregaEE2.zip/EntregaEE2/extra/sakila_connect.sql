CREATE DATABASE sakila_dwh2 ENGINE = MySQL('mariadb:3306', 'sakila', 'usuario_sak', 'contra') SETTINGS read_write_timeout = 10000, connect_timeout = 100;
